<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title mb-30">
                        <h2>Change Password</h2>
                    </div>
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card-style mb-30">
                    <div class="form-wrapper">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                      <form action="<?php echo e(route('password.change')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                          <div class="col-12">
                            <div class="input-style-1">
                              <label>Current Password</label>
                              <input name="current_password" type="password" class="<?php if(session('error')): ?> is-invalid <?php endif; ?>" placeholder="Current Password" autofocus />
                              <?php if(session('error')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e(session('error')); ?></strong>
                                </span>
                              <?php endif; ?>
                            </div>
                          </div>
                          <!-- end col -->
                          <div class="col-12">
                            <div class="input-style-1">
                              <label>New Password</label>
                              <input name="password" type="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="New Password" />
                              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                            <!-- end col -->
                            <div class="col-12">
                                <div class="input-style-1">
                                  <label>Confirm Password</label>
                                  <input name="password_confirmation" type="password" placeholder="Password Again" />
                                </div>
                            </div>
                            <!-- end col -->
                          <div class="col-12">
                            <div
                              class="
                                button-group
                                d-flex
                                justify-content-center
                                flex-wrap
                              "
                            >
                              <button
                                type="submit"
                                class="
                                  main-btn
                                  primary-btn
                                  btn-hover
                                  w-100
                                  text-center
                                "
                              >
                              Change Password
                              </button>
                            </div>
                          </div>
                        </div>
                        <!-- end row -->
                      </form>
                    </div>
                </div>
            </div>
            <!-- End Col -->
        </div>
        <!-- End Row -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\magicpixel\resources\views/admin/change-password.blade.php ENDPATH**/ ?>