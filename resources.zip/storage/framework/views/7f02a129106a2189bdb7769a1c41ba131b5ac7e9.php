<?php if($paginator->lastPage() > 1): ?>
<small>Showing <?php echo e($paginator->currentPage()); ?> of <?php echo e($paginator->lastPage()); ?> pages </small>
<ul class="pagination">
    <li class="page-item <?php echo e(($paginator->currentPage() == 1) ? ' disabled' : ''); ?>">
        <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()-1)); ?>" >Previous</a>
    </li> 
    <?php if($paginator->currentPage() == $paginator->lastPage() && $paginator->lastPage() > 2): ?>
        <li class="page-item">
            <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()-2)); ?>"><?php echo e($paginator->currentPage()-2); ?></a>
        </li>
    <?php endif; ?>
    <?php if($paginator->currentPage() != 1): ?>   
        <li class="page-item">
            <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()-1)); ?>"><?php echo e($paginator->currentPage()-1); ?></a>
        </li>
    <?php endif; ?>
    
    <li class="page-item active">
        <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage())); ?>"><?php echo e($paginator->currentPage()); ?></a>
    </li>
    <?php if($paginator->currentPage() != $paginator->lastPage()): ?>
        <li class="page-item">
            <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>"><?php echo e($paginator->currentPage()+1); ?></a>
        </li>
    <?php endif; ?>
    <?php if($paginator->currentPage() == 1 && $paginator->lastPage() > 2): ?>
        <li class="page-item">
            <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()+2)); ?>"><?php echo e($paginator->currentPage()+2); ?></a>
        </li>
    <?php endif; ?>
    <li class="page-item <?php echo e(($paginator->currentPage() == $paginator->lastPage()) ? ' disabled' : ''); ?>">
        <a class="page-link" href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>" >Next</a>
    </li>
</ul>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\adminpanel\resources\views/admin/partials/pagination.blade.php ENDPATH**/ ?>