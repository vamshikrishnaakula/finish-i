<?php $__env->startSection('title', 'Roles List'); ?>
<?php $__env->startSection('content'); ?>



<div class="card shadow mt-2">
    <div class="card-body">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Role Management</h1>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
            <a href="<?php echo e(route('roles.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Create New Role</a>
            <?php endif; ?>
        </div>


        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <div class="table-wrapper table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>
                            <h6>Role</h6>
                        </th>
                        <!-- <th>
                            <h6>Permissions</h6>
                        </th> -->
                        <th>
                            <h6>Status</h6>
                        </th>
                        <th>
                            <h6>Action</h6>
                        </th>
                    </tr>
                    <!-- end table row-->
                </thead>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($role->role_name); ?></td>
                    <!-- <td><?php echo e(implode(", ", array_column($role->permissions->toArray(), 'permission_name'))); ?></td> -->
                    <td><?php echo status($role->status); ?></td>
                    <td>
                        <div class="d-flex">
                            <a class="main-btn primary-btn-outline rounded-md btn-hover me-2" href="<?php echo e(route('roles.edit',$role->id)); ?>"><i class="lni lni-pencil"></i></a>
                            <?php if($role->status == 'D'): ?>
                                <form action="<?php echo e(route('roles.activate',$role->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="main-btn danger-btn-outline rounded-md btn-hover" href=""><i class="lni lni-checkmark-circle"></i></button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('roles.destroy',$role->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="main-btn danger-btn-outline rounded-md btn-hover" href=""><i class="lni lni-trash-can"></i></button>
                                </form>
                            <?php endif; ?>
                            
                        </div>
                        
                        
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>

        <?php echo $roles->links('admin.partials.pagination'); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminpanel\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>