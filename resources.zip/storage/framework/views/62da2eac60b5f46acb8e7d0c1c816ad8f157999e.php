<footer class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-6 order-last order-md-first">
              <div class="copyright text-center text-md-start">
                <p class="text-sm">
                  © <?php echo e(now()->year); ?> Magic Pixel. All Rights Reserved
                </p>
              </div>
            </div>
            <!-- end col-->
            <div class="col-md-6">
              <div
                class="
                  terms
                  d-flex
                  justify-content-center justify-content-md-end
                "
              >
                <a href="https://magicpixel.io/privacy-policy/" target="_blank" class="text-sm">Privacy Policy</a>
                <a href="https://magicpixel.io/contact-us/" target="_blank" class="text-sm ml-15">Contact us</a>
              </div>
            </div>
          </div>
          <!-- end row -->
        </div>
        <!-- end container -->
      </footer><?php /**PATH C:\xampp\htdocs\magicpixel\resources\views/partials/footer.blade.php ENDPATH**/ ?>