<?php $__env->startSection('content'); ?>



<div class="card shadow">
    <div class="card-body">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit Role</h1>
            <a href="<?php echo e(route('roles.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-caret-left fa-sm text-white-50"></i> Back</a>
        </div>

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <form action="<?php echo e(route('roles.update',$role->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="input-style-1">
                <label>Role Name</label>
                <input type="text" placeholder="Role Name" name="role_name" value="<?php echo e($role->role_name); ?>" />
            </div>
            <h6 class="mb-25">Permissions</h6>
            <div class="row">
                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check checkbox-style mb-10 col-3">
                    <input class="form-check-input" name="permission[]" type="checkbox" value="<?php echo e($p->id); ?>" id="checkbox-<?php echo e($p->id); ?>" <?php echo e(in_array($p->id, $rolePermissions) ? 'checked' : ''); ?> />
                    <label class="form-check-label" for="checkbox-<?php echo e($p->id); ?>"><?php echo e($p->permission_name); ?></label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center">
                <button type="submit" class="main-btn primary-btn rounded-md btn-hover">Update</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\adminpanel\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>