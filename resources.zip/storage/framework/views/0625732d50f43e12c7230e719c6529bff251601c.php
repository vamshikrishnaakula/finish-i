<aside class="sidebar-nav-wrapper">
    <div class="navbar-logo">
        <a href="<?php echo e(route('dashboard')); ?>">
            <img src="<?php echo e(asset('images/mp.png')); ?>" class="w-100" alt="logo" />
        </a>
    </div>
    <nav class="sidebar-nav">
        <ul>
            <li class="nav-item <?php if(request()->routeIs('dashboard')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('dashboard')); ?>">
                    <span class="icon">
                      <i class="lni lni-dashboard"></i>
                    </span>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#">
                    <span class="icon">
                      <i class="lni lni-cog"></i>
                    </span>
                    <span class="text">Notifications</span>
                </a>
            </li>

            
        </ul>
    </nav>
</aside>
<div class="overlay"></div>
<?php /**PATH C:\xampp\htdocs\magicpixel\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>