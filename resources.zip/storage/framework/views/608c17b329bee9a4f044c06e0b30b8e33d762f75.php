<aside class="sidebar-nav-wrapper">
  <div class="navbar-logo">
    <a href="<?php echo e(route('dashboard')); ?>">
      <img src="<?php echo e(asset('images/logo.png')); ?>" class="w-100" alt="logo" />
    </a>
  </div>
  <nav class="sidebar-nav">
    <ul>
      <li class="nav-item <?php if(request()->routeIs('dashboard')): ?> active <?php endif; ?>">
        <a href="<?php echo e(route('dashboard')); ?>">
          <span class="icon">
            <i class="lni lni-dashboard"></i>
          </span>
          <span class="text">Dashboard</span>
        </a>
      </li>
      <li class="nav-item nav-item-has-children">
        <a href="#0" class="collapsed" data-bs-toggle="collapse" data-bs-target="#roles" aria-controls="roles" aria-expanded="false" aria-label="Toggle navigation">
          <span class="icon">
            <i class="lni lni-dashboard"></i>
          </span>
          <span class="text">Roles</span>
        </a>
        <ul id="roles" class="collapse dropdown-nav">
          <li>
            <a class="<?php if(Route::is('roles.index')): ?> active <?php endif; ?>" href="<?php echo e(route('roles.index')); ?>"> Role List</a>
          </li>
          <li>
            <a class="<?php if(Route::is('roles.create')): ?> active <?php endif; ?>" href="<?php echo e(route('roles.create')); ?>"> Create Role </a>
          </li>
        </ul>
      </li>
      <li class="nav-item nav-item-has-children <?php if(request()->routeIs('users')): ?> active <?php endif; ?>">
        <a href="#0" class="collapsed" data-bs-toggle="collapse" data-bs-target="#users" aria-controls="users" aria-expanded="false" aria-label="Toggle navigation">
          <span class="icon">
            <i class="lni lni-dashboard"></i>
          </span>
          <span class="text">Users</span>
        </a>
        <ul id="users" class="collapse dropdown-nav  <?php if(Route::is('users.*')): ?> show <?php endif; ?>">
          <li>
            <a class="<?php if(Route::is('users.index')): ?> active <?php endif; ?>" href="<?php echo e(route('users.index')); ?>"> Users List </a>
          </li>
          <li>
            <a class="<?php if(Route::is('users.create')): ?> active <?php endif; ?>" href="<?php echo e(route('users.create')); ?>"> Create User</a>
          </li>
        </ul>
      </li>

      <li class="nav-item nav-item-has-children <?php if(Route::is('eventtypes.*')): ?> active <?php endif; ?>">
        <a href="#0" class="collapsed" data-bs-toggle="collapse" data-bs-target="#eventtypes" aria-controls="eventtypes" aria-expanded="false" aria-label="Toggle navigation">
          <span class="icon">
            <i class="lni lni-dashboard"></i>
          </span>
          <span class="text">Event Types</span>
        </a>
        <ul id="eventtypes" class="collapse dropdown-nav">
          <li>
            <a class="<?php if(Route::is('eventtypes.index')): ?> active <?php endif; ?>" href="<?php echo e(route('eventtypes.index')); ?>"> Event Types List</a>
          </li>
          <li>
            <a class="<?php if(Route::is('eventtypes.create')): ?> active <?php endif; ?>" href="<?php echo e(route('eventtypes.create')); ?>"> Create Event Types</a>
          </li>
        </ul>
      </li>
      <li class="nav-item nav-item-has-children <?php if(Route::is('events.*')): ?> active <?php endif; ?>">
        <a href="#0" class="collapsed" data-bs-toggle="collapse" data-bs-target="#eventcategory" aria-controls="eventcategory" aria-expanded="false" aria-label="Toggle navigation">
          <span class="icon">
            <i class="lni lni-dashboard"></i>
          </span>
          <span class="text">Events Category</span>
        </a>
        <ul id="eventcategory" class="collapse dropdown-nav">
          <li>
            <a class="<?php if(Route::is('eventcategories.index')): ?> active <?php endif; ?>" href="<?php echo e(route('eventcategories.index')); ?>"> Event Categories List</a>
          </li>
          <li>
            <a class="<?php if(Route::is('eventcategories.create')): ?> active <?php endif; ?>" href="<?php echo e(route('eventcategories.create')); ?>"> Create Event Category</a>
          </li>
        </ul>
      </li>
      <li class="nav-item nav-item-has-children <?php if(Route::is('events.*')): ?> active <?php endif; ?>">
        <a href="#0" class="collapsed" data-bs-toggle="collapse" data-bs-target="#events" aria-controls="events" aria-expanded="false" aria-label="Toggle navigation">
          <span class="icon">
            <i class="lni lni-dashboard"></i>
          </span>
          <span class="text">Events</span>
        </a>
        <ul id="events" class="collapse dropdown-nav">
          <li>
            <a class="<?php if(Route::is('events.index')): ?> active <?php endif; ?>" href="<?php echo e(route('events.index')); ?>"> Events List</a>
          </li>
          <li>
            <a class="<?php if(Route::is('events.create')): ?> active <?php endif; ?>" href="<?php echo e(route('events.create')); ?>"> Create Event </a>
          </li>
        </ul>
      </li>
      <li class="nav-item">
        <a href="#">
          <span class="icon">
            <i class="lni lni-cog"></i>
          </span>
          <span class="text">Notifications</span>
        </a>
      </li>

      
    </ul>
  </nav>
</aside>
<div class="overlay"></div><?php /**PATH C:\xampp\htdocs\adminpanel\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>