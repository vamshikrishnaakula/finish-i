<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="shortcut icon"
      href="<?php echo e(asset('images/fav.png')); ?>"
      type="image/x-icon"
    />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />

    <!-- ========== All CSS files linkup ========= -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>" />
  </head>
  <body>
      <?php echo $__env->yieldContent('content'); ?>

    <!-- ========= All Javascript files linkup ======== -->
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\magicpixel\resources\views/layouts/auth.blade.php ENDPATH**/ ?>